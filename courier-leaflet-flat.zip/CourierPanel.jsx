
import React from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline } from 'react-leaflet';

const defaultCenter = { lat: 49.4608, lng: 30.1247 };

function CourierPanel({ deliveries }) {
  const [currentPosition, setCurrentPosition] = React.useState(defaultCenter);
  const [selectedDelivery, setSelectedDelivery] = React.useState(null);

  React.useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setCurrentPosition({
            lat: pos.coords.latitude,
            lng: pos.coords.longitude,
          });
        },
        () => {
          setCurrentPosition(defaultCenter);
        }
      );
    }
  }, []);

  const route = selectedDelivery
    ? [
        [currentPosition.lat, currentPosition.lng],
        [selectedDelivery.lat, selectedDelivery.lng],
      ]
    : [];

  return (
    <div>
      <h2>Мої доставки</h2>
      <div style={{ display: 'flex', gap: '20px', flexWrap: 'wrap' }}>
        <ul style={{ flex: 1, minWidth: '200px' }}>
          {deliveries.map((d) => (
            <li
              key={d.id}
              onClick={() => setSelectedDelivery(d)}
              style={{
                cursor: 'pointer',
                fontWeight: selectedDelivery?.id === d.id ? 'bold' : 'normal',
                marginBottom: '10px',
              }}
            >
              {d.address} — {d.status}
            </li>
          ))}
        </ul>
        <div style={{ flex: 3, height: '400px', minWidth: '300px' }}>
          <MapContainer
            center={[currentPosition.lat, currentPosition.lng]}
            zoom={12}
            style={{ height: '100%', width: '100%' }}
          >
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            <Marker position={[currentPosition.lat, currentPosition.lng]}>
              <Popup>Ви тут</Popup>
            </Marker>
            {selectedDelivery && (
              <>
                <Marker position={[selectedDelivery.lat, selectedDelivery.lng]}>
                  <Popup>Доставка: {selectedDelivery.address}</Popup>
                </Marker>
                <Polyline positions={route} color="blue" />
              </>
            )}
          </MapContainer>
        </div>
      </div>
    </div>
  );
}

export default CourierPanel;
