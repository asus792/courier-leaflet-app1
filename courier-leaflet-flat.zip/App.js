
import React from 'react';
import CourierPanel from './CourierPanel';

function App() {
  const deliveries = [
    {
      id: '1',
      address: 'вул. Центральна, Ржищів',
      status: 'В процесі',
      lat: 49.4608,
      lng: 30.1247,
    },
    {
      id: '2',
      address: 'вул. Хрещатик, Київ',
      status: 'Доставлено',
      lat: 50.4501,
      lng: 30.5234,
    },
  ];

  return <CourierPanel deliveries={deliveries} />;
}

export default App;
